#pragma once

#include "sope.h"
#include "aux_functions.h"

int checkArgs(int argc, char *argv[]);